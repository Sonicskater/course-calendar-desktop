package database;
import java.util.ArrayList;

public class Course {
	public ArrayList<String> Antilist = new ArrayList<String>();
	public ArrayList<String> Prelist = new ArrayList<String>();
	public String Name;
	
	public Course(String n) {
		Name = n;
	}
	@Override
	public String toString() {
	    return Name;
	}

}
