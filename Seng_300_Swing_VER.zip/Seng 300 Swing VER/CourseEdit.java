import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.Course;
import database.Program;

import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CourseEdit extends JFrame {
	JList listC;
	JList listAnti;
	JList listPre;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public CourseEdit(Course C, ArrayList<Course> Clist) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollC = new JScrollPane();
		scrollC.setBounds(10, 11, 180, 300);
		contentPane.add(scrollC);
		
		listC = new JList(Clist.toArray());
		listC.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollC.setViewportView(listC);
		
		JScrollPane scrollAnti = new JScrollPane();
		scrollAnti.setBounds(200, 11, 180, 300);
		contentPane.add(scrollAnti);
		
		listAnti = new JList(C.Antilist.toArray());
		listAnti.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollAnti.setViewportView(listAnti);
		
		JScrollPane scrollPre = new JScrollPane();
		scrollPre.setBounds(390, 11, 184, 300);
		contentPane.add(scrollPre);
		
		listPre = new JList(C.Prelist.toArray());
		listPre.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPre.setViewportView(listPre);
		
		JLabel lblCourses = new JLabel("Courses");
		lblCourses.setBounds(20, 322, 101, 14);
		contentPane.add(lblCourses);
		
		JLabel lblAntireq = new JLabel("Antireq");
		lblAntireq.setBounds(210, 322, 101, 14);
		contentPane.add(lblAntireq);
		
		JLabel lblPrereq = new JLabel("Prereq");
		lblPrereq.setBounds(400, 322, 92, 14);
		contentPane.add(lblPrereq);
		
		JLabel Message = new JLabel("");
		Message.setBounds(10, 436, 564, 14);
		contentPane.add(Message);
		
		JButton btnAddAnti = new JButton("AddAnti");
		btnAddAnti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = listC.getSelectedValue().toString();
				if(!C.Antilist.contains(s)) {
					C.Antilist.add(s);
					listAnti = new JList(C.Antilist.toArray());
					scrollAnti.setViewportView(listAnti);
					Message.setText("Course " + s + " added to antireq of Course " + C.Name);
				}
			}
		});
		btnAddAnti.setBounds(10, 347, 89, 23);
		contentPane.add(btnAddAnti);
		
		JButton btnAddPre = new JButton("AddPre");
		btnAddPre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = listC.getSelectedValue().toString();
				if(!C.Prelist.contains(s)) {
					C.Prelist.add(s);
					listPre = new JList(C.Prelist.toArray());
					scrollPre.setViewportView(listPre);
					Message.setText("Course " + s + " added to prereq of Course " + C.Name);
				}
			}
		});
		btnAddPre.setBounds(10, 381, 89, 23);
		contentPane.add(btnAddPre);
		
		JButton btnRemoveAnti = new JButton("Remove Anti");
		btnRemoveAnti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = listAnti.getSelectedValue().toString();
				C.Antilist.remove(s);
				listAnti = new JList(C.Antilist.toArray());
				scrollAnti.setViewportView(listAnti);
				Message.setText("Course " + s + " removed from antireq of Course " + C.Name);
			}
		});
		btnRemoveAnti.setBounds(200, 347, 111, 23);
		contentPane.add(btnRemoveAnti);
		
		JButton btnRemovePre = new JButton("Remove Pre");
		btnRemovePre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = listPre.getSelectedValue().toString();
				C.Prelist.remove(s);
				listPre = new JList(C.Prelist.toArray());
				scrollPre.setViewportView(listPre);
				Message.setText("Course " + s + " removed from prereq of Course " + C.Name);
			}
		});
		btnRemovePre.setBounds(390, 347, 122, 23);
		contentPane.add(btnRemovePre);
		
	}

}
