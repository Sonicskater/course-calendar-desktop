import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.Course;
import database.Department;
import database.Program;

import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProgramEdit extends JFrame {
	JList listC;
	JList listPC;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public ProgramEdit(Program P, ArrayList<Course> Clist) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 490, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollC = new JScrollPane();
		scrollC.setBounds(10, 11, 220, 250);
		contentPane.add(scrollC);
		
		listC = new JList(Clist.toArray());
		listC.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollC.setViewportView(listC);
		
		JScrollPane scrollPC = new JScrollPane();
		scrollPC.setBounds(240, 11, 220, 250);
		contentPane.add(scrollPC);
		
		listPC = new JList(P.Clist.toArray());
		scrollPC.setViewportView(listPC);
		
		JLabel lblCourses = new JLabel("Courses");
		lblCourses.setBounds(20, 272, 79, 14);
		contentPane.add(lblCourses);
		
		JLabel lblCoursesInProgram = new JLabel("Courses In Program");
		lblCoursesInProgram.setBounds(250, 272, 165, 14);
		contentPane.add(lblCoursesInProgram);
		
		JLabel Message = new JLabel("");
		Message.setBounds(10, 331, 450, 14);
		contentPane.add(Message);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!nameInPC(listC.getSelectedValue().toString(), P)) {
					P.Clist.add((Course) listC.getSelectedValue());
					listPC = new JList(P.Clist.toArray());
					scrollPC.setViewportView(listPC);
					Message.setText("Course " + listC.getSelectedValue().toString() + " added to Program " + P.Name);
				}
				else {
					Message.setText("Course " + listC.getSelectedValue().toString() + " already in Program " + P.Name);
				}
			}
		});
		btnAdd.setBounds(10, 297, 89, 23);
		contentPane.add(btnAdd);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cn = listPC.getSelectedValue().toString();
				P.Clist.remove((Course) listPC.getSelectedValue());
				listPC = new JList(P.Clist.toArray());
				scrollPC.setViewportView(listPC);
				Message.setText("Program " + cn + " removed from Department " + P.Name);
			}
		});
		btnRemove.setBounds(240, 297, 89, 23);
		contentPane.add(btnRemove);
		
	}
	public boolean nameInPC(String s, Program P) {
		for(Course C:P.Clist) {
			if(C.Name.equals(s)) {
				return true;
			}
		}
		return false;
	}
}
