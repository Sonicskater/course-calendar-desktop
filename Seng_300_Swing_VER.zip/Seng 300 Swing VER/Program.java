package database;
import java.util.ArrayList;

public class Program {
	public ArrayList<Course> Clist = new ArrayList<Course>();
	public String Name;
	
	public Program(String n) {
		Name = n;
	}
	@Override
	public String toString() {
	    return Name;
	}

}
