package database;
import java.util.ArrayList;

public class Department {
	public ArrayList<Program> Plist = new ArrayList<Program>();
	public String Name;
	
	public Department(String n) {
		Name = n;
	}
	@Override
	public String toString() {
	    return Name;
	}

}
