import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.Department;
import database.Program;

import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DepartmentEdit extends JFrame {
	JList listP;
	JList listDP;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public DepartmentEdit(Department D, ArrayList<Program> Plist) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 490, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollP = new JScrollPane();
		scrollP.setBounds(10, 11, 220, 250);
		contentPane.add(scrollP);
		
		listP = new JList(Plist.toArray());
		listP.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollP.setViewportView(listP);
		
		JScrollPane scrollDP = new JScrollPane();
		scrollDP.setBounds(240, 11, 220, 250);
		contentPane.add(scrollDP);
		
		listDP = new JList(D.Plist.toArray());
		scrollDP.setViewportView(listDP);
		
		JLabel lblPrograms = new JLabel("Programs");
		lblPrograms.setBounds(20, 272, 79, 14);
		contentPane.add(lblPrograms);
		
		JLabel lblProgramsInDepartment = new JLabel("Programs In Department");
		lblProgramsInDepartment.setBounds(250, 272, 165, 14);
		contentPane.add(lblProgramsInDepartment);
		
		JLabel Message = new JLabel("");
		Message.setBounds(10, 331, 450, 14);
		contentPane.add(Message);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!nameInDP(listP.getSelectedValue().toString(), D)) {
					D.Plist.add((Program) listP.getSelectedValue());
					listDP = new JList(D.Plist.toArray());
					scrollDP.setViewportView(listDP);
					Message.setText("Program " + listP.getSelectedValue().toString() + " added to Department " + D.Name);
				}
				else {
					Message.setText("Program " + listP.getSelectedValue().toString() + " already in Department " + D.Name);
				}
			}
		});
		btnAdd.setBounds(10, 297, 89, 23);
		contentPane.add(btnAdd);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pn = listDP.getSelectedValue().toString();
				D.Plist.remove((Program) listDP.getSelectedValue());
				listDP = new JList(D.Plist.toArray());
				scrollDP.setViewportView(listDP);
				Message.setText("Program " + pn + " removed from Department " + D.Name);
			}
		});
		btnRemove.setBounds(240, 297, 89, 23);
		contentPane.add(btnRemove);
		
	}
	public boolean nameInDP(String s, Department D) {
		for(Program P:D.Plist) {
			if(P.Name.equals(s)) {
				return true;
			}
		}
		return false;
	}
}
