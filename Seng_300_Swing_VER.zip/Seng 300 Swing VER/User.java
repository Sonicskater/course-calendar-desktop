import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTree;
import javax.swing.ListModel;

import java.awt.Color;
import java.awt.SystemColor;
import java.util.ArrayList;

import javax.swing.tree.DefaultTreeModel;

import database.Course;
import database.Department;
import database.Program;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JScrollPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class User extends JFrame {
	public ArrayList<Department> Dlist;
	public ArrayList<Program> Plist;
	public ArrayList<Course> Clist;

	private JPanel contentPane;
	private JTextField txtName;
	
	public JList listD;
	public JList listP;
	public JList listC;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User frame = new User();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public User() {
		Dlist = new ArrayList<Department>();
		Plist = new ArrayList<Program>();
		Clist = new ArrayList<Course>();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 287, 300);
		contentPane.add(scrollPane);
		
		JTree tree = new JTree();
		tree.setBackground(SystemColor.control);
		scrollPane.setViewportView(tree);
		
		JRadioButton DepartmentRadioButton = new JRadioButton("Department");
		DepartmentRadioButton.setBounds(10, 318, 89, 23);
		contentPane.add(DepartmentRadioButton);
		
		JRadioButton ProgramRadioButton = new JRadioButton("Program");
		ProgramRadioButton.setBounds(109, 318, 89, 23);
		contentPane.add(ProgramRadioButton);
		
		JRadioButton CourseRadioButton = new JRadioButton("Course");
		CourseRadioButton.setBounds(208, 318, 89, 23);
		contentPane.add(CourseRadioButton);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(DepartmentRadioButton);
		bg.add(ProgramRadioButton);
		bg.add(CourseRadioButton);
		
		JButton AddButton = new JButton("Add");
		AddButton.setBounds(10, 348, 89, 23);
		contentPane.add(AddButton);
		
		JButton EditButton = new JButton("Edit");
		EditButton.setBounds(109, 348, 89, 23);
		contentPane.add(EditButton);
		
		JButton DeleteButton = new JButton("Delete");
		DeleteButton.setBounds(208, 348, 89, 23);
		contentPane.add(DeleteButton);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(307, 11, 217, 300);
		contentPane.add(scrollPane_1);
		
		listD = new JList(Dlist.toArray());
		listD.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPane_1.setViewportView(listD);
		
		listP = new JList(Plist.toArray());
		listP.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPane_1.setViewportView(listP);
		
		listC = new JList(Clist.toArray());
		listC.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPane_1.setViewportView(listC);
		
		txtName = new JTextField();
		txtName.setBounds(307, 349, 86, 20);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel Message = new JLabel("");
		Message.setBounds(10, 382, 383, 14);
		contentPane.add(Message);
		
		DepartmentRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				scrollPane_1.setViewportView(listD);
			}
		});
		
		ProgramRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				scrollPane_1.setViewportView(listP);
			}
		});
		
		CourseRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				scrollPane_1.setViewportView(listC);
			}
		});
		
		AddButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(DepartmentRadioButton.isSelected()) {
					Department D = new Department(txtName.getText());
					if (!nameInDepartment(D.Name)) {
						Dlist.add(D);
						Message.setText("Added Department " + txtName.getText());
						listD = new JList(Dlist.toArray());
						scrollPane_1.setViewportView(listD);
					}
					else {
						Message.setText("Department already exits. Pick a diffrent name.");
					}
				}
				else if(ProgramRadioButton.isSelected()) {
					Program P = new Program(txtName.getText());
					if (!nameInProgram(P.Name)) {
						Plist.add(P);
						Message.setText("Added Program " + txtName.getText());
						listP = new JList(Plist.toArray());
						scrollPane_1.setViewportView(listP);
					}
					else {
						Message.setText("Program already exits. Pick a diffrent name.");
					}
				}
				else if(CourseRadioButton.isSelected()) {
					Course C = new Course(txtName.getText());
					if (!nameInCourse(C.Name)) {
						Clist.add(C);
						Message.setText("Added Course " + txtName.getText());
						listC = new JList(Clist.toArray());
						scrollPane_1.setViewportView(listC);
					}
					else {
						Message.setText("Course already exits. Pick a diffrent name.");
					}
				}
				else {
					Message.setText("Select from above");
				}
			}
		});
		DeleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(DepartmentRadioButton.isSelected()) {
					Department D = (Department) listD.getSelectedValue();
					Dlist.remove(D);
					Message.setText("Removed Department " + D.Name);
					listD = new JList(Dlist.toArray());
					scrollPane_1.setViewportView(listD);
				}
				else if(ProgramRadioButton.isSelected()) {
					Program P = (Program) listP.getSelectedValue();
					Plist.remove(P);
					Message.setText("Removed Program " + P.Name);
					listP = new JList(Plist.toArray());
					scrollPane_1.setViewportView(listP);
				}
				else if(CourseRadioButton.isSelected()) {
					Course C = (Course) listC.getSelectedValue();
					Clist.remove(C);
					Message.setText("Removed Course " + C.Name);
					listC = new JList(Clist.toArray());
					scrollPane_1.setViewportView(listC);
				}
				else {
					Message.setText("Select from above");
				}
			}
		});
		
		EditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(DepartmentRadioButton.isSelected()) {
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								DepartmentEdit frame = new DepartmentEdit((Department) listD.getSelectedValue(), Plist);
								frame.setVisible(true);
							} catch (Exception e) {
								Message.setText("Please select from list");
							}
						}
					});
				}
				else if(ProgramRadioButton.isSelected()) {
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								ProgramEdit frame = new ProgramEdit((Program) listP.getSelectedValue(), Clist);
								frame.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
								Message.setText("Please select from list");
							}
						}
					});
				}
				else if(CourseRadioButton.isSelected()) {
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								CourseEdit frame = new CourseEdit((Course) listC.getSelectedValue(), Clist);
								frame.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				}
				else {
					Message.setText("Select from above");
				}
			}
		});
		
	}
	public boolean nameInDepartment(String s) {
		for(Department D : Dlist) {
			if (D.Name.equals(s)) {
				return true;
			}
		}
		return false;
	}
	public boolean nameInProgram(String s) {
		for(Program P : Plist) {
			if (P.Name.equals(s)) {
				return true;
			}
		}
		return false;
	}
	public boolean nameInCourse(String s) {
		for(Course C : Clist) {
			if (C.Name.equals(s)) {
				return true;
			}
		}
		return false;
	}
	
}
