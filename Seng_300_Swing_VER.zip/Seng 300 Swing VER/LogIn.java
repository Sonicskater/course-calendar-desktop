import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;

import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class LogIn {

	private JFrame frame;
	private JTextField txtUsername;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogIn window = new LogIn();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LogIn() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(116, 329, 86, 20);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(116, 354, 86, 20);
		frame.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		JLabel UsernameLabel = new JLabel("Username");
		UsernameLabel.setBounds(10, 332, 69, 14);
		frame.getContentPane().add(UsernameLabel);
		
		JLabel PasswordLabel = new JLabel("Password");
		PasswordLabel.setBounds(10, 357, 69, 14);
		frame.getContentPane().add(PasswordLabel);
		
		JRadioButton FacultyRadioButton = new JRadioButton("Faculty");
		FacultyRadioButton.setBounds(220, 328, 109, 23);
		frame.getContentPane().add(FacultyRadioButton);
		
		JRadioButton StudentRadioButton = new JRadioButton("Student");
		StudentRadioButton.setBounds(220, 353, 109, 23);
		frame.getContentPane().add(StudentRadioButton);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(StudentRadioButton);
		bg.add(FacultyRadioButton);
		
		JButton LoginButton = new JButton("Login");
		LoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							User frame = new User();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		LoginButton.setBounds(335, 342, 89, 23);
		frame.getContentPane().add(LoginButton);
		
		JLabel LogoImage = new JLabel("");
		LogoImage.setIcon(new ImageIcon("Logo.png"));
		LogoImage.setBounds(10, 11, 414, 290);
		frame.getContentPane().add(LogoImage);
	}
}
